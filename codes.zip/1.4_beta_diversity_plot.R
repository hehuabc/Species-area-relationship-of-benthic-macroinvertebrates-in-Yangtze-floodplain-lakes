##########################################################################
##########################################################################

# loading packages
library(tidyverse)
library(mobr)
library(data.table)

# 1. set your own workplace and loading data set ##################################
work_dir <- setwd("C:/Users/hehu/Documents/data/2024_zoobenthos_china_zhangyou")


# 2. linear regression ############################################

data <- readRDS("./data/pairwise_diversity_env_data.Rds") %>% setDT()

var <- count(data,index)$index

scales <- count(data,scale)$scale

fit <- list()

stat_coeff <- list()

fit2 <- list()

stat_coeff2 <- list()

for (j in 1:length(scales)) {
  
  data2 <- data[scale == scales[j]]
  
  for (i in 1 : length(var)){
    
    library(glmmTMB)
    
    library(ggeffects)
    
    if (scales[j] != "beta" ){
      
      data3 <- data2[index == var[i]] %>% 
        
        # for alpha and gamma diversity, we log-transformed diversity
        
        mutate(area = log10(area),value = log10(value)) %>% 
        
        select(lake,area,value,index,longitute,latitude)
    
      } else
      
        data3 <- data2[index == var[i]] %>% 
        
          # for beta diversity, we did not log-transformed
          
          mutate(area = log10(area)) %>% 
        
          select(lake,area,value,index,longitute,latitude)
    
    # first we need to create a numeric factor recording the coordinates of the sampled locations
    
    data3$pos <- numFactor(scale(data3$longitute),scale(data3$latitude))
    
    # then create a dummy group factor to be used as a random term
    
    data3$ID <- factor(rep(1, nrow(data3)))
    
    # fit models
    
    fit_full <- glmmTMB(data = na.omit(data3),
                        value ~ area + mat(pos+0|ID),
                        family = gaussian(link = "identity"))
    summary(fit_full)
    AIC(fit_full)
    # if model can not converged, then remove matern structure

    if (is.na(AIC(fit_full))) {
      
      fit_full <- glmmTMB(data = na.omit(data3),
                          value ~ area,
                          family = gaussian(link = "identity"))
    }
    
     
    stat_coeff[[i]] <- summary(fit_full)$coefficients$cond %>% 
      as.data.frame(row.names = F) %>%
      cbind(index = var[i],
            coeff = c("intercept","area"))
    
    ## define the significance
    
    if(summary(fit_full)$coefficients$cond[8] < 0.05){
      
        fit[[i]] <- ggpredict(fit_full,terms = "area") %>% 
      
            as.data.frame() %>%
        
          cbind(index = var[i],sig = "S")
        
    } else
      
      fit[[i]] <- ggpredict(fit_full,terms = "area") %>%
      as.data.frame() %>%
      cbind(index = var[i],sig = "S_not")
    
  }

  ## generate a table
  
  stat_coeff2[[j]] <- bind_rows(stat_coeff) %>% 
    cbind(scale = scales[j])%>%
    dplyr::rename('SE' = 'Std. Error',
                  'Pr' = "Pr(>|z|)") %>%
    mutate(upper = round(Estimate + 1.96*SE,3),
           lower = round(Estimate - 1.96*SE,3))
  
  fit2[[j]] <- bind_rows(fit) %>% cbind(scale = scales[j])
  
}

stat_coeff3 <- bind_rows(stat_coeff2) 

fit3 <- bind_rows(fit2) %>% select(!group)

write.csv(stat_coeff3,"./data/beta_stat_coefficients.csv")

saveRDS(fit3,"./data/beta_fit.Rds")


## 3. plot figure 3 #####################################################
data <- readRDS("./data/pairwise_diversity_env_data.Rds") %>% setDT()

stat_coeff3 <- read.csv("./data/beta_stat_coefficients.csv",header = T)

fit3 <- readRDS("./data/beta_fit.Rds")

data_beta2 <- data %>% 
  left_join(stat_coeff3,by = c("index","scale"))

data_beta3 <- filter(data_beta2,scale == "beta") %>% 
  cbind(group = 0)

data_beta4 <- filter(data_beta2,scale != "beta") %>% 
  cbind(group = 1) %>%
  mutate(value = log10(value))

data_beta5 <- bind_rows(data_beta3,data_beta4)

fit3 <- setDT(fit3)

fitx <- filter(fit3,scale == "beta") %>% cbind(group = 0)

fity <- filter(fit3,scale != "beta") %>% cbind(group = 1)

fit4 <- bind_rows(fitx,fity)

data_beta5$index <- factor(data_beta5$index,
                            levels = c("S_n","S_PIE"),
                            labels = c(expression(italic(S)[n]),
                                       expression(italic(S)[PIE])))
fit4$index <- factor(fit3$index,
                     levels = c("S_n","S_PIE"),
                     labels = c(expression(italic(S)[n]),
                                expression(italic(S)[PIE])))

a <- count(fit4,index)$index

fit4$group <- factor(fit4$group,levels = c(1,0))

tiff("./figures/beta_div.tiff",res = 1200,compression = "lzw",
     width = 14,height = 12,units = "cm")

ggplot(data_beta5,aes(log10(area),(value))) +
  geom_point(aes(color = scale),alpha = 0.3,shape = 1,
             size =2, 
             show.legend = F) +
  facet_grid(group~index,labeller = label_parsed,scales = "free_y") +
  theme_bw() +
  ## adding fitted lines
  geom_line(data = fit4,
            aes(x = x,y = predicted,
                color = scale,linetype = sig),size =0.5) +
  ## adding CI area
  geom_ribbon(data = fit4,
              aes(x = x,y = predicted,
                  fill = scale,
                  ymin = (conf.low), 
                  ymax = (conf.high)),alpha = 0.3) + 
  theme(aspect.ratio = 4/5,
        legend.position = "none",
        strip.text.y = element_blank(),
        axis.title = element_text(size = 10)) +
  labs(x = expression(lg~(Area)~(km^2)),
       y = expression(Diversity)) +
  scale_color_manual(values = c("salmon3","black","blue")) +
  scale_fill_manual(values = c("salmon3","black","blue")) +
  geom_text(data = fit4[scale == "beta" & index == a[1]],
            aes(x = 3, y = 2,
                label = "��"),
            alpha = 0.3,size = 4) +
  geom_text(data = fit4[scale == "beta" & index == a[2]],
            aes(x = 3, y = 2,
                label = "��"),
            alpha = 0.3,size = 4) +
  geom_text(data = fit4[scale == "alpha"& index == a[1]],
            aes(x = 3, y = 0.3,
                label = "lg(��)"),
            alpha = 0.5,size = 4) +
  geom_text(data = fit4[scale == "alpha"& index == a[2]],
            aes(x = 3, y = 0.3,
                label = "lg(��)"),
            alpha = 0.5,size = 4) +
  geom_text(data = fit4[scale == "gamma"& index == a[1]],
            aes(x = 3, y = 0.8,
                label = "lg(��)"),
            alpha = 0.5,size = 4) +
  geom_text(data = fit4[scale == "gamma"& index == a[2]],
            aes(x = 3, y = 0.6,
                label = "lg(��)"),
            alpha = 0.5,size = 4) +
  geom_text(data = data_beta5[coeff == "area"&scale == "beta"&index == a[1]],
            aes(x = 2, y = 2.8, 
                label = paste0('Slope = ',round(Estimate,3)," (",lower," - ",upper,")")),
            alpha = 0.02,size = 2.5) +
  geom_text(data = data_beta5[coeff == "area"&scale == "beta"&index == a[2]],
            aes(x = 2, y = 2.8, 
                label = paste0('Slope = ',round(Estimate,3)," (",lower," - ",upper,")")),
            alpha = 0.02,size = 2.5) +
  geom_text(data = data_beta5[coeff == "area"&scale == "gamma"&index == a[1]],
            aes(x = 2, y = 1.3, 
                label = paste0('Slope = ',round(Estimate,3)," (",lower," - ",upper,")",' (��)')),
            alpha = 0.02,size = 2.5) +
  geom_text(data = data_beta5[coeff == "area"&scale == "alpha"&index == a[1]],
            aes(x = 2, y = 1.2, 
                label = paste0('Slope = ',round(Estimate,3)," (",lower," - ",upper,")",' (��)')),
            alpha = 0.02,size = 2.5) +
  geom_text(data = data_beta5[coeff == "area"&scale == "gamma"&index == a[2]],
            aes(x = 2, y = 1.3, 
                label = paste0('Slope = ',round(Estimate,3)," (",lower," - ",upper,")",' (��)')),
            alpha = 0.02,size = 2.5) +
  geom_text(data = data_beta5[coeff == "area"&scale == "alpha"&index == a[2]],
            aes(x = 2, y = 1.2, 
                label = paste0('Slope = ',round(Estimate,3)," (",lower," - ",upper,")",' (��)')),
            alpha = 0.02,size = 2.5) 


dev.off()



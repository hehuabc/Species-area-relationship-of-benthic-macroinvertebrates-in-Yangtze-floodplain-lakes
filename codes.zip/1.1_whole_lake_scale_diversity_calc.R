##########################################################################

# Description : This script can be used to 
# calculate the following diversity indices:
# S_asympt (Stotal), Sn, S_PIE, following 'mobr' terminology


# loading packages
library(tidyverse)
library(mobr)
library(data.table)

# 1. set your own workplace and loading data set ##################################
work_dir <- setwd("C:/Users/hehu/Documents/data/2024_zoobenthos_china_zhangyou")

# species data (89 lakes located in Yangtze River Basin)
comm <- read.csv("./data/zoobenthos.csv",header = T) 

# env data
env <- read.csv("./data/env_ecography.csv",header = T) # site level

# 2. biodiversity metrics ##########################

## calculate efforts
### we used the double of minimum abundance of each site as a reference N

n_ref <- 2*(rowSums(comm[-c(1:3)]) %>% min())

## calculate biodiversity metrics
mob_in <- make_mob_in(comm[-c(1:3)],env,
                      coord_names = c("longitute",
                                      "latitude"),
                      latlong = T)

stats <- get_mob_stats(mob_in,
                       group_var = "lake",
                       index = c("N",
                                 "S_n",
                                 "S_PIE",
                                 "S_asymp"),
                       effort_samples = n_ref)


### alpha (single sample level)

data_alpha <- stats$samples_stats %>% 
  as.data.frame() %>%
  dplyr::filter(index == "N"|
                  index == "S_n"|
                  index == "S_PIE"|
                  index == "S") %>%
  dplyr::rename("lake" = "group") 


data_alpha2 <- cbind(data_alpha,site = env$site) %>%
  full_join(env,by = c("lake","site"))

saveRDS(data_alpha2,"./analysis/data_alpha.Rds")


data_alpha_mean <- group_by(data_alpha,lake,index,effort) %>% 
  summarise_if(is.numeric,mean) %>% ungroup() %>% distinct() 

saveRDS(data_alpha_mean,"./data/data_alpha_mean.Rds")

### whole-lake level
data_gamma <- stats$groups_stats %>% distinct() %>%
  filter(index != "S_n"| effort == n_ref) %>%
  select(group,index,value)%>%
  rename("lake" = "group") %>% 
  full_join(env2,by = c("lake"))

saveRDS(data_gamma,"./data/data_gamma.Rds")








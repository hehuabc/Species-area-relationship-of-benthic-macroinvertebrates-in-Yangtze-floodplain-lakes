##########################################################################
##########################################################################
# Here we plot diversity in lake-level (gamma-scale),
# we want to see whether ISAR emerges only because of passive sampling

# loading packages
library(tidyverse)
library(mobr)
library(data.table)
library(spdep)
library(SoDA)
library(ape)

# 1. set your own workplace and loading data set ##################################
work_dir <- setwd("C:/Users/hehu/Documents/data/2024_zoobenthos_china_zhangyou")

# 2. GLMM regression ################################################

data_gamma <- readRDS("./data/data_gamma.Rds") %>% setDT() 

var <- levels(data_gamma$index)

# a list for save fitting values
fit <- list()

# a list for save statistical results
stat_coeff <- list()

for (i in 1 : length(var)){
   
  data <- data_gamma[index == var[i]] %>% 
    mutate(value = log10(value),area = log10(area)) %>% 
    select(lake,area,value,index,longitute,latitude)
  
  library(glmmTMB)
  
  library(ggeffects)
  
  # first we need to create a numeric factor recording the coordinates of the sampled locations
  data$pos <- numFactor(scale(data$longitute), scale(data$latitude))
  
  # then create a dummy group factor to be used as a random term
  data$ID <- factor(rep(1, nrow(data)))
 
  
  # the function "mat" used for controlling spatial autocorrelation
  fit_full <- glmmTMB(data = na.omit(data),
                      value ~ area + mat(pos+0|ID),
                      family = gaussian(link = "identity"))
   
  ## if convergence problem, remove the matern structure
  
  if(is.na(AIC(fit_full))){
    
    fit_full <- glmmTMB(data = na.omit(data),
                         value ~ area,
                         family = gaussian(link = "identity"))
     
     
   }
  
  ## calculate R2 for model
  library(MuMIn)
  
  r.squaredGLMM(fit_full)
  
  stat_coeff[[i]] <- summary(fit_full)$coefficients$cond %>% 
    as.data.frame(row.names = F) %>%
    cbind(index = var[i],
          coeff = c("intercept","area"))
  
  fit[[i]] <- ggpredict(fit_full,terms = "area") %>% 
    as.data.frame() %>%
    cbind(index = var[i]) 
}

stat_coeff2 <- bind_rows(stat_coeff) %>%
  dplyr::rename('SE' = 'Std. Error',
                'Pr' = "Pr(>|z|)") %>%
  mutate(upper = round(Estimate + 1.96*SE,3),
         lower = round(Estimate - 1.96*SE,3))

fit2 <- bind_rows(fit)

# save the statical results as a table
write.csv(stat_coeff2,"./data/gamma_stat_coefficients.csv")

# save fitting values
saveRDS(fit2,"./data/gamma_fit.Rds")

## 3. plot Fig. 2 ###########################################################

data_gamma <- readRDS("./data/data_gamma.Rds") %>% setDT() 

stat_coeff2 <- read.csv("./data/gamma_stat_coefficients.csv")

fit2 <- readRDS("./data/gamma_fit.Rds")

data_gamma2 <- data_gamma %>% left_join(stat_coeff2,by = "index")

data_gamma3 <- filter(data_gamma2,index != "N") %>% setDT()

fit3 <- filter(fit2,index != "N") %>% setDT()

data_gamma3$index <- factor(data_gamma3$index,
                           levels = c("S_asymp","S_n","S_PIE"),
                           labels = c(expression(italic(S)[total]),
                                      expression(italic(S)[n]),
                                      expression(italic(S)[PIE])))

fit3$index <- factor(fit3$index,
                            levels = c("S_asymp","S_n","S_PIE"),
                            labels = c(expression(italic(S)[total]),
                                       expression(italic(S)[n]),
                                       expression(italic(S)[PIE])))

a <- dplyr::count(data_gamma3,index)$index

tiff("./figures/gamma_div.tiff",res = 1200,compression = "lzw",
     width = 14,height = 5.5,units = "cm")

ggplot(data_gamma3,aes(log10(area),log10(value))) +
  geom_point(alpha = 1,shape = 1,size = 1.5, color = "gray40",
             show.legend = F) +
  facet_wrap(.~index,labeller = label_parsed,ncol = 4) +
  theme_bw() +
  ## adding fitted lines
  geom_line(data = fit3[index != a[3]],aes(x = x,y = predicted)) +
  geom_line(data = fit3[index == a[3]],aes(x = x,y = predicted),
            linetype = "dashed") +
  ## adding CI area
  geom_ribbon(data = fit3[index != a[3]],
              aes(x = x,y = predicted,
                  ymin = conf.low, ymax = conf.high),
              alpha = 0.2) + 
  geom_ribbon(data = fit3[index == a[3]],
              aes(x = x,y = predicted,
                  ymin = conf.low, ymax = conf.high),alpha = 0.2) + 
  theme(aspect.ratio = 4/5,
        axis.title = element_text(size = 10)) +
  labs(x = expression(lg~(Area)~(km^2)),
       y = expression(lg~(Species~number))) +
  geom_text(data = data_gamma3[coeff == "area"],
    aes(x = 2, y = 2, 
                label = paste0("Slope = ",round(Estimate,3)," (",lower," - ",upper,")")),
            alpha = 0.02,size = 2.5) 
  
dev.off()


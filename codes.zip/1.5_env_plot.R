##########################################################################

# loading packages
library(tidyverse)
library(mobr)
library(data.table)

# 1. set your own workplace and loading data set ##################################
work_dir <- setwd("C:/Users/hehu/Documents/data/2024_zoobenthos_china_zhangyou")

data_alpha <- read.csv("./data/env_ecography.csv") %>% 
  group_by(lake) %>% 
  summarise_if(is.numeric,mean)

# 2. nutrients #########################################################
library(glmmTMB)

# TN
fit1 <- glmmTMB(data = data_alpha,log10(tn)~log10(area) ,
            family = gaussian(link = "identity"))

summary(fit1)

# TP
fit2 <- glmmTMB(data = data_alpha,log10(tp)~log10(area) ,
                family = gaussian(link = "identity"))

summary(fit2)

## plot TN and TP

data_alpha2 <- select(data_alpha, lake,area,tn,tp) %>% 
  distinct() %>% setDT()

plot_tn <- ggplot(data_alpha2,aes(log10(area),log10(tn))) +
  geom_point(
             alpha = 0.5,shape = 1,size =2,
             show.legend = F) +
  geom_smooth(data = data_alpha2,
              method = "lm",linetype = "dashed",
              color = "black",size = 0.3)  +
  theme_bw() +
  theme(aspect.ratio = 1) +
  labs(x = expression(lg~(Area)~(km^2)),
       y = expression(lg~(TN)~(mg~L^{-1}))) +
  geom_text(data = data_alpha2,
            aes(x = 1.35, y = 1, 
                label = paste0('slope = ',0.063)),
            size = 3)+
  
  geom_text(data = data_alpha2,
            aes(x = 2.35, y = 1, 
                label = paste0("p = 0.180")),
            size = 3) +
  
  geom_text(data = data_alpha2,
            aes(x = 3.1, y = 1, 
                label = paste0("(n = 89)")),
           size = 3) 
plot_tn

plot_tp <- ggplot(data_alpha2,aes(log10(area),log10(tp))) +
  geom_point(alpha = 0.5,shape = 1,size =2,
             show.legend = F) +
  geom_smooth(data = data_alpha2,
              method = "lm",linetype = "dashed",
              color = "black",size = 0.3)  +
  theme_bw() +
  theme(aspect.ratio = 1) +
  labs(x = expression(lg~(Area)~(km^2)),
       y = expression(lg~(TP)~(mg~L^{-1}))) +
  geom_text(data = data_alpha2,
            aes(x = 1.35, y = 0, 
                label = paste0('slope = ',-0.006)),
            size = 3)+
  geom_text(data = data_alpha2,
            aes(x = 2.35, y = 0, 
                label = paste0("p = 0.905")),
            size = 3) +
  geom_text(data = data_alpha2,
            aes(x = 3.1, y = 0, 
                label = paste0("(n = 89)")),
            size = 3) 
plot_tp


# 3. fish ###########################################################
data_alpha <- read.csv("./data/env_ecography.csv",
                       fileEncoding = "UTF-8-BOM") %>% 
  setDT() %>% select(lake,depth,area) %>% distinct()

fish <- read.csv("./data/fish_ecography.csv",
                 fileEncoding = "UTF-8-BOM") %>% setDT() 

fish2 <- left_join(fish,data_alpha,by = "lake") %>% arrange(area)

fit_area_fish <- lm(data = fish2,
                  formula = log10(number)~log10(area)) 

summary(fit_area_fish)


fish_plot <- ggplot(fish2,aes(log10(area),log10(number/2))) +
  geom_point(shape = 1,
             show.legend = F,alpha = 0.5,size = 2) + 
  geom_smooth(method = "lm",color = "black",linetype = "dashed",size = 0.5) +
  theme_bw() +
  theme(aspect.ratio = 1) +
  labs(x = expression(lg~(Area)~(km^{2})),
       y = expression(lg~(CPUE)~(ind~net^{-1}~h^{-1}))) +
  scale_x_continuous(limits = c(0.8,3.7),breaks = c(1,2,3)) +
  annotate("text",x = 1.4, y = 3, label = paste0('slope = ',-0.155),
            alpha = 1,size = 3) +
  annotate("text",x = 2.5, y = 3, label = paste0("p = 0.338"),
           alpha = 1,size = 3) +
  annotate("text", x = 3.3,y = 3, size = 3,label = "(n = 36)") 

fish_plot

# 4. macrophytes--------------------------------
data_alpha <- read.csv("./data/env_ecography.csv") %>% group_by(lake) %>% 
  summarise_if(is.numeric,mean) %>% 
  select(lake,area)

plant <- read.csv("./data/plant_cover_remote_sensing_ecography.csv") %>% 
  group_by(lake) %>%
  dplyr::summarise(coverage = mean(coverage)) %>% 
  ungroup()
  
  

data_all <- left_join(plant,data_alpha,
                      by = c("lake")) %>% 
  mutate(area1 = log(area)) %>%
  na.omit() %>% 
  setDT() %>% distinct()


library(glmmTMB)

fit <- glmmTMB(data = data_all,
               log10(coverage) ~ log10(area1), 
               family = gaussian())

summary(fit)

plants <- ggplot(data_all,
                 aes(log10(area),log10(coverage))) +
  geom_point(shape = 1,
             show.legend = F,alpha = 0.5,size = 2) +
  theme_bw() + 
  theme(aspect.ratio = 1) +
  geom_smooth(data = data_all,
              method = "lm",formula = y~poly(x,1),
              linetype = 'dashed',color = "black",size = 0.5) +
  labs(x = expression(lg~(Area)~(km^{2})),
       y = expression(lg~(Plant~coverage)~("%"))) +
  annotate("text", x = 3.1,y = 3, size = 3,label = "(n = 78)") +
  
  annotate("text",x = 1.4, y = 3, label = paste0('slope = ',0.059),
           alpha = 1,size = 3) +
  
  annotate("text",x = 2.35, y = 3,size = 3,label = paste0('p = ','0.800'))
  
plants


## the range of TN AND TP for each lake

# 5. pairwise nutrient difference ##################################
work_dir <- setwd("C:/Users/hehu/Documents/data/2024_zoobenthos_china_zhangyou")

# env data
env <- read.csv("./data/env_ecography.csv",header = T) 



# split the data into pairs 
lakename <- plyr::count(env$lake)$x

all_data_out <- list()

for (i in 1:length(lakename)) {
  
  gamma_tab <-  filter(env,lake == lakename[i]) %>% distinct()
  
  gamma_tab[is.na(gamma_tab)] <- 0
  
  # split data into lake pairs
  pair <- list()
  
  a <- length(gamma_tab$lake)
  
  for (d in 1:(a-1)) {
    
    for (e in (d+1):a) {
      
      num = paste(d,e,sep = "") %>% as.numeric()
      
      pair[[num]] <- gamma_tab[c(d,e),] 
      
    }
    
  }
  
  pair = pair[-which(sapply(pair, is.null))]
  
  all_data_out[[i]] <- bind_rows(pair)
  
}

all_data_out <- bind_rows(all_data_out) 

x <- rep(1:(length(all_data_out$date)/2),each = 2)  

all_data_out <- all_data_out %>% cbind(x) %>% select(lake,area,tn,tp,x)

min_tn <- tapply(all_data_out$tn, all_data_out$x, min) %>% as.data.frame()

max_tn <- tapply(all_data_out$tn, all_data_out$x, max) %>% as.data.frame()

data_tn <- cbind(min_tn,max_tn) 

colnames(data_tn) <- c("min","max")

x <- row.names(data_tn)

data_tn <- cbind(data_tn,x) %>% mutate(range = max - min) 

area <- select(all_data_out,lake,area,x)%>% distinct() 

area$x <- as.character(area$x)

data_tn2 <- left_join(area,data_tn,by = "x") %>%
  group_by(lake,area) %>% summarise(range = mean(range))


lm(data = data_tn2,log10(range)~log10(area)) %>% summary()


plot_tn_diff <- ggplot(data_tn2,aes(log10(area),log10(range))) + 
  geom_point(shape = 1,alpha = 0.5,size = 2) +
  theme_bw() + 
  theme(aspect.ratio = 1) +
  geom_smooth(
              method = "lm",formula = y~poly(x,1),
              color = "black",size = 0.5) +
  labs(x = expression(lg~(Area)~(km^{2})), 
       y = expression(lg~(TN~difference)~(mg~L^{-1}))) +
  geom_text(aes(x = 1.35, y = 1, 
                label = paste0('slope = ',0.377)),
            size = 3)+
  
  geom_text(aes(x = 2.35, y = 1, 
                label = paste0("p < 0.001")),
            size = 3) +
  
  geom_text(aes(x = 3.1, y = 1, 
                label = paste0("(n = 89)")),
            size = 3) 

plot_tn_diff


min_tp <- tapply(all_data_out$tp, all_data_out$x, min) %>% as.data.frame()

max_tp <- tapply(all_data_out$tp, all_data_out$x, max) %>% as.data.frame()

data_tp <- cbind(min_tp,max_tp) 

colnames(data_tp) <- c("min","max")

x <- row.names(data_tp)

data_tp <- cbind(data_tp,x) %>% mutate(range = max - min) 

area <- select(all_data_out,lake,area,x)%>% distinct() 

area$x <- as.character(area$x)

data_tp2 <- left_join(area,data_tp,by = "x") %>%
  group_by(lake,area) %>% summarise(range = mean(range))

lm(data = filter(data_tp2,range > 0),log10(range)~log10(area)) %>% summary()

plot_tp_diff <- ggplot(data_tp2,aes(log10(area),log10(range))) + 
  geom_point(shape = 1,alpha = 0.5,size = 2) +
  theme_bw() + 
  theme(aspect.ratio = 1) +
  geom_smooth(
    method = "lm",formula = y~poly(x,1),
    color = "black",size = 0.5) +
  labs(x = expression(lg~(Area)~(km^{2})), 
       y = expression(lg~(TP~difference)~(mg~L^{-1}))) +
  geom_text(aes(x = 1.35, y = 0, 
                label = paste0('slope = ',0.174)),
            size = 3)+
  
  geom_text(aes(x = 2.35, y = 0, 
                label = paste0("p < 0.034")),
            size = 3) +
  
  geom_text(aes(x = 3.1, y = 0, 
                label = paste0("(n = 89)")),
            size = 3) 

plot_tp_diff






# 6. group Figures ######################################################

tiff("./figures/co-variables.tiff",res = 1200,compression = "lzw",
     width = 14,height = 21,units = "cm")

library(ggpubr)

ggarrange(plot_tn,plot_tp,
          fish_plot,plants,
          plot_tn_diff,plot_tp_diff,
          ncol= 2,nrow = 3,
          align = "hv",labels = "auto")

dev.off()



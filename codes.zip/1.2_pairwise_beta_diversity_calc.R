##########################################################################

# Description : This script can be used to pairwise beta diversity
# calculate the following diversity indices: Sn, S_PIE, following 'mobr' terminology


# loading packages
library(tidyverse)
library(mobr)
library(data.table)

# 1. set your own workplace and loading data set ##################################
work_dir <- setwd("C:/Users/hehu/Documents/data/2024_zoobenthos_china_zhangyou")

# species data (84 lakes located in Yangtze River Basin)
comm <- read.csv("./data/zoobenthos.csv",header = T) 

## calculate efforts
### we used the minimum abundance of each site as a reference N
n_ref <- 2*(rowSums(comm[-c(1:3)]) %>% min())

# 2. split the data into pairs ###################################
lakename <- plyr::count(comm$lake)$x

all_data_out <- list()

for (i in 1:length(lakename)) {

  gamma_tab <-  filter(comm,lake == lakename[i]) %>% distinct()
  
  gamma_tab[is.na(gamma_tab)] <- 0
  
  # split data into lake pairs
  pair <- list()
  
  a <- length(gamma_tab$lake)
  
  for (d in 1:(a-1)) {
    
    for (e in (d+1):a) {
      
      num = paste(d,e,sep = "") %>% as.numeric()
      
      pair[[num]] <- gamma_tab[c(d,e),] 
      
    }
    
  }
  
  pair = pair[-which(sapply(pair, is.null))]
  
  all_data_out[[i]] <- bind_rows(pair)
  
 }
  
all_data_out <- bind_rows(all_data_out) 

x <- rep(1:(length(all_data_out$date)/2),each = 2)  

all_data_out <- all_data_out %>% cbind(x)

# 3. calculate metrics in pairs ##########################

  div_all <- list()

  for (j in 1:max(x)) {
    
    data_alpha <- filter(all_data_out,x == j) %>% select(!x)
    
    data_gamma <-  data_alpha[,-2] %>% group_by(date) %>%
      summarise_all(sum) %>%
      ungroup()
    
    # create a clue
    lake_pairs <- select(data_alpha,2:3)
    
    ##alpha
    alpha_div <- calc_biodiv(data_alpha[,-c(1:3)],
                               groups = data_alpha$date,
                               index = c("S_n","S_PIE"),
                               effort = n_ref,
                               extrapolate = T,
                               return_NA = F) %>% 
      cbind(scale = "alpha") %>% 
      cbind(lake_pairs)
    
    ## gamma
    gamma_div <- calc_biodiv(data_gamma[-c(1:2)],
                                  groups = data_gamma$date ,
                                  index = c("S_n","S_PIE"),
                                  effort = n_ref,
                                  extrapolate = T,
                                  return_NA = F) %>% 
      cbind(scale = "gamma",lake = data_alpha$lake) 
    
    ## beta 
    beta_div <- alpha_div %>%
      left_join(gamma_div, by = c("group", "index","lake")) %>%
      mutate(value = value.y/value.x) %>%
      select(group,index,lake,value) %>%
      group_by(index,group) %>%
      summarise(value = mean(value, na.rm = T),.groups = "drop") %>%
      ungroup %>%
      cbind(scale = "beta",lake = data_alpha$lake)
    
    alpha_div_mean <- alpha_div %>% 
      group_by(group,lake,index,scale,effort) %>%
      summarise(value = mean(value, na.rm = T),.groups = "drop") %>%
      ungroup()
    
    div_all[[j]] <- bind_rows(gamma_div,
                              beta_div,
                              alpha_div_mean) %>% 
      cbind(x = j) %>%
      dplyr::rename("date" = "group")
    
  }
  
all_div_out <- bind_rows(div_all)
 
all_div_out2 <- group_by(all_div_out,lake,scale,index) %>%
  summarise(value = mean(value)) %>% 
  ungroup()

saveRDS(all_div_out2,file = "./data/pairwise_diversity_data.Rds")

# env data
env <- read.csv("./data/env_ecography.csv",header = T) # site level

env2 <- group_by(env,lake) %>% summarise_if(is.numeric,mean,na.rm = T) # lake level

data <- all_div_out2 %>% left_join(env2,by = "lake")

saveRDS(data,file = "./data/pairwise_diversity_env_data.Rds")



